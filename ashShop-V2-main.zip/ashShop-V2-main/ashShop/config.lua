Config = {
    ShopPos = {
        {pos = vector3(-707.30, -914.66, 19.21), blips = true},
        {pos = vector3(25.742, -1345.741, 29.497), blips = true},
        {pos = vector3(373.875, 325.896, 103.66), blips = true},
        {pos = vector3(2557.458, 382.282, 108.722), blips = true},
        {pos = vector3(-3038.939, 585.954, 6.97), blips = true},
        {pos = vector3(-3241.927, 1001.462, 12.850), blips = true},
        {pos = vector3(547.431, 2671.710, 42.176), blips = true},
        {pos = vector3(1961.464, 3740.672, 32.363), blips = true},
        {pos = vector3(2678.916, 3280.671, 55.261), blips = true},
        {pos = vector3(1729.216, 6414.131, 35.057), blips = true},
        {pos = vector3(1135.808, -982.281, 46.45), blips = true},
        {pos = vector3(-1222.93, -906.99, 12.35), blips = true},
        {pos = vector3(-1487.553, -379.107, 40.163), blips = true},
        {pos = vector3(-2968.243, 390.910, 15.054), blips = true},
        {pos = vector3(1166.024, 2708.930, 38.167), blips = true},
        {pos = vector3(1392.562, 3604.684, 34.995), blips = true},
        {pos = vector3(-1393.409, -606.624, 30.319), blips = true},
        {pos = vector3(-48.519, -1757.514, 29.47), blips = true},
        {pos = vector3(1163.373, -323.801, 69.27), blips = true},
        {pos = vector3(-1820.523, 792.518, 138.20), blips = true},
        {pos = vector3(1698.388, 4924.404, 42.083), blips = true},
    },

    FoodItems = {
        {label = "Pain", item = "bread", price = 50},
    },
    BoissonItems = {
        {label = "Eau", item = "water", price = 25},
    },
    DiversItem = {
        {label = "Téléphone", item = "phone", price = 25},
    }
}
