# nShop-V2
discord.gg/ntdev
